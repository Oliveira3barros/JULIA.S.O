let cor;
let cores;
let  circux;
let circuy;
function setup() {
  createCanvas(600, 400);
background("green");
  cor =color(random(0,255))
}

function draw() {

}